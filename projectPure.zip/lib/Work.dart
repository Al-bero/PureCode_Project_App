import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ScrollablePage(),
    );
  }
}

class ScrollablePage extends StatelessWidget {
  final List<String> dummyText = [
    "Online booking Portal for Umrah and Hajj Packages",
    "AlMuehi Legal Services website",
    "Social Development Bank",
    "Artificial Intelligence Application",
    "A website Solution for Rent A Car",
  ];

  final List<String> imagePaths = [
    'assets/images/m1.png', // Replace with your image asset paths
    'assets/images/m2.png',
    'assets/images/m3.png',
    'assets/images/m4.png',
    'assets/images/m5.png',
  ];

  Future<void> _launchExternalLink() async {
    const url = 'https://www.example.com'; // Replace with your external link
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Color(0xFF333E50)), // Set the icon color
        actions: [
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 16.0),
                  child: Image.asset('assets/images/Logo with Font - png.png', width: 100), // Replace with your logo image
                ),
                Builder(
                  builder: (BuildContext context) {
                    return IconButton(
                      icon: Icon(Icons.menu),
                      onPressed: () {
                        Scaffold.of(context).openDrawer();
                      },
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color:  Color(0xFF2BBFB0), // Set drawer header background color
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      'PureCode Project',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20.0,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              title: Text('Our Work'),
              onTap: () {
                // Handle drawer item tap to navigate
                Navigator.pop(context); // Close the drawer
              },
            ),
            // Add more ListTile items for other navigation options
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Center( // Center-align the boxes
          child: Column(
            children: List.generate(
              dummyText.length,
              (index) => Container(
                width: 294, // Set width for the box
                height: 103, // Set height for the box
                margin: EdgeInsets.all(16.0),
                padding: EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10.0),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 2,
                      blurRadius: 3,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image.asset(
                      imagePaths[index], // Use the corresponding image path for this index
                      height: 70.0, // Adjust the image height
                    ),
                    SizedBox(width: 16.0), // Add spacing between image and text
                    Expanded(
                      child: Text(
                        dummyText[index],
                        style: TextStyle(
                          fontSize: 16.0,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF2C607D),
                        ),
                      ),
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        ElevatedButton(
                          onPressed: _launchExternalLink,
                          style: ElevatedButton.styleFrom(
                            primary: Color.fromRGBO(170, 222, 217, 0.65), // #AADED9 (65% opacity)
                            textStyle: TextStyle(color: Colors.black),
                            minimumSize: Size(79, 25),
                          ),
                          child: Text('Visit'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Color(0xFF333E50),
        unselectedItemColor: Colors.white,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Our Work',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Else',
          ),
        ],
      ),
    );
  }
}
